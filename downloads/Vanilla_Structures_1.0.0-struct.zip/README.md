# Vanilla Structures

*Created by [Th3Emilis](https://mcpedl.com/user/th3emilis/)*

Conveniently generate vanilla structures anywhere in your world!

## Terms of Use

By downloading, using or interacting in any way with this add-on, you agree to the following terms:
- **No Derivates.** You can remix, adapt or build upon the add-on as long as it is for private use (this means that you may not publish or distribute it anywhere).
- **Non-Commercial.** You may not monetise, sell, or profit off the add-on in any way.
- **Redistribution.** You may not redistribute or republish the add-on.
- **Sharing.** You may not share the direct download link or any user-made link of the add-on. Use the official GitHub release link.
- **Attribution.** You may give proper credit if any of the add-on contents (UI, files, etc.) appear in your content, such as videos.
- **No bundling.** You may not include the add-on files or snippets from them in other add-ons. You may, however, provide a link to the add-on’s official GitHub release page.

## Genuineness

Not sure you have the real deal? For your peace of mind, download the add-on from [the repo](https://github.com/Th3Emilis/vanilla-structures) or [my Discord server](https://discord.gg/z9ngSYp).

## Feedback

Whether you have an idea to improve the add-on, find a bug, or face an issue you need help with, [let me know](https://discord.gg/z9ngSYp)!